#include <iostream>
#include "hello.h"
using namespace std;

int main() {
    cout << "Hello, World!" << endl;
    return 0;
}
