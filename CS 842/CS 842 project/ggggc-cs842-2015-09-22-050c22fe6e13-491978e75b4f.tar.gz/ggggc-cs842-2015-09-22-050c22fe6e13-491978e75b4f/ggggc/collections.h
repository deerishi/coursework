#ifndef GGGGC_COLLECTIONS_H
#define GGGGC_COLLECTIONS_H 1

#include "collections/list.h"
#include "collections/map.h"
#include "collections/unit.h"

#endif
